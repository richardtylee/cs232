# Be sure to restart your server when you modify this file.

Cs232demo::Application.config.session_store :cookie_store, key: '_cs232demo_session'
